package com.abosila.islamichub;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

import java.io.IOException;

public class AdhanService extends Service {

    private static final String CHANNEL_ID = "adhan_channel";
    private MediaPlayer player;
    private PowerManager.WakeLock wakeLock;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        String type = intent.getStringExtra("type");
        String prayerKey = intent.getStringExtra("prayerKey");
        String prayerName = intent.getStringExtra("prayerName");

        if (type == null) type = "adhan";
        if (prayerName == null) prayerName = "الصلاة";
        if (prayerKey == null) prayerKey = "fajr";

        boolean isPre = "pre".equals(type);

        String title = isPre ? "تنبيه: اقتربت صلاة " + prayerName : "حان الآن موعد صلاة " + prayerName;
        String body = isPre ? "باقي 5 دقائق على الأذان" : "الله أكبر • حان وقت الصلاة";

        // Acquire wake lock so the sound finishes even if screen is off
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AboSila:AdhanWake");
            wakeLock.acquire(10 * 60 * 1000L); // max 10 min
        }

        Intent openApp = new Intent(this, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentPi = PendingIntent.getActivity(this, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setContentIntent(contentPi)
                .setAutoCancel(true)
                .setOngoing(!isPre) // keep notification while full adhan plays
                .build();

        startForeground(42, notification);

        playSound(isPre, prayerKey);

        return START_NOT_STICKY;
    }

    private void playSound(boolean isPre, String prayerKey) {
        releasePlayer();

        String assetPath;
        if (isPre) {
            switch (prayerKey) {
                case "fajr":    assetPath = "audio/pre_fajr.mp3"; break;
                case "dhuhr":   assetPath = "audio/pre_dhuhr.mp3"; break;
                case "asr":     assetPath = "audio/pre_asr.mp3"; break;
                case "maghrib": assetPath = "audio/pre_maghrib.mp3"; break;
                case "isha":    assetPath = "audio/pre_isha.mp3"; break;
                default:        assetPath = "audio/pre_fajr.mp3"; break;
            }
        } else {
            assetPath = "audio/adhan_makkah.mp3";
        }

        try {
            player = new MediaPlayer();
            android.content.res.AssetFileDescriptor afd = getAssets().openFd(assetPath);
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build());
            } else {
                player.setAudioStreamType(android.media.AudioManager.STREAM_ALARM);
            }

            player.setOnCompletionListener(mp -> {
                releasePlayer();
                stopForeground(true);
                stopSelf();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                releasePlayer();
                stopForeground(true);
                stopSelf();
                return true;
            });

            player.prepare();
            player.start();
        } catch (IOException e) {
            releasePlayer();
            stopForeground(true);
            stopSelf();
        }
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                if (player.isPlaying()) player.stop();
                player.release();
            } catch (Exception ignored) {}
            player = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
            wakeLock = null;
        }
    }

    @Override
    public void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
