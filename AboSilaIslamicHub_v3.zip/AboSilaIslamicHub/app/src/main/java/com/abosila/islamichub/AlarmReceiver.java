package com.abosila.islamichub;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String type = intent.getStringExtra("type");
        String prayerKey = intent.getStringExtra("prayerKey");
        String prayerName = intent.getStringExtra("prayerName");

        if (type == null) type = "adhan";
        if (prayerName == null) prayerName = "الصلاة";
        if (prayerKey == null) prayerKey = "fajr";

        Intent service = new Intent(context, AdhanService.class);
        service.putExtra("type", type);
        service.putExtra("prayerKey", prayerKey);
        service.putExtra("prayerName", prayerName);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(service);
        } else {
            context.startService(service);
        }
    }
}
