package com.abosila.islamichub;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Calendar;

public class MainActivity extends Activity {

    WebView web;
    private static final String CHANNEL_ID = "adhan_channel";
    private static final int REQ_PERMS = 100;
    private static final int REQ_NOTIF = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createNotificationChannel();
        requestNeededPermissions();

        getWindow().setStatusBarColor(Color.rgb(10, 25, 35));
        getWindow().setNavigationBarColor(Color.rgb(10, 25, 35));

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(10, 25, 35));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }
        });

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "تنبيهات الأذان",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("تنبيهات ما قبل الأذان والأذان");
            channel.enableVibration(true);
            channel.setSound(null, null); // sound handled by service
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    }, REQ_PERMS);
        }

        // Exact alarm permission (Android 12+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception ignored) {}
            }
        }
    }

    public class Bridge {

        @JavascriptInterface
        public void shareImage(String data, String caption) {
            try {
                String raw = data.substring(data.indexOf(',') + 1);
                byte[] bytes = Base64.decode(raw, Base64.DEFAULT);
                File f = new File(getCacheDir(), "abo-sila-card.png");
                FileOutputStream out = new FileOutputStream(f);
                out.write(bytes);
                out.close();
                Uri uri = FileProvider.getUriForFile(MainActivity.this,
                        getPackageName() + ".provider", f);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("image/png");
                i.putExtra(Intent.EXTRA_STREAM, uri);
                i.putExtra(Intent.EXTRA_TEXT, caption);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "مشاركة بطاقة إسلامية"));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "تعذر تجهيز الصورة: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }

        @JavascriptInterface
        public void shareText(String text) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(i, "مشاركة"));
        }

        /**
         * Schedule pre-adhan (5 min before) + adhan for each prayer.
         * timesJson example:
         * {"fajr":"04:52","dhuhr":"11:55","asr":"15:10","maghrib":"17:42","isha":"19:05"}
         */
        @JavascriptInterface
        public void schedulePrayers(String timesJson) {
            try {
                JSONObject times = new JSONObject(timesJson);
                SharedPreferences prefs = getSharedPreferences("prayer_times", MODE_PRIVATE);
                prefs.edit().putString("last_times", timesJson)
                        .putLong("saved_at", System.currentTimeMillis())
                        .apply();

                cancelAllAlarms();

                String[] keys = {"fajr", "dhuhr", "asr", "maghrib", "isha"};
                String[] names = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};

                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (am == null) return;

                Calendar now = Calendar.getInstance();

                for (int i = 0; i < keys.length; i++) {
                    String t = times.optString(keys[i], null);
                    if (t == null || t.equals("—") || !t.contains(":")) continue;

                    String[] parts = t.split(":");
                    int hour = Integer.parseInt(parts[0].trim());
                    int minute = Integer.parseInt(parts[1].trim());

                    // Adhan time
                    Calendar adhanCal = Calendar.getInstance();
                    adhanCal.set(Calendar.HOUR_OF_DAY, hour);
                    adhanCal.set(Calendar.MINUTE, minute);
                    adhanCal.set(Calendar.SECOND, 0);
                    adhanCal.set(Calendar.MILLISECOND, 0);

                    if (adhanCal.before(now)) {
                        adhanCal.add(Calendar.DAY_OF_YEAR, 1);
                    }

                    // Pre-notice 5 minutes before
                    Calendar preCal = (Calendar) adhanCal.clone();
                    preCal.add(Calendar.MINUTE, -5);

                    if (preCal.after(now)) {
                        setExactAlarm(am, preCal.getTimeInMillis(),
                                1000 + i, "pre", keys[i], names[i]);
                    }

                    setExactAlarm(am, adhanCal.getTimeInMillis(),
                            2000 + i, "adhan", keys[i], names[i]);
                }

                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "تم جدولة تنبيهات الصلاة (قبل 5 دقائق + الأذان)", Toast.LENGTH_SHORT).show());

            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "خطأ في الجدولة: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void cancelAlarms() {
            cancelAllAlarms();
            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "تم إلغاء كل التنبيهات", Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public boolean hasExactAlarmPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                return am != null && am.canScheduleExactAlarms();
            }
            return true;
        }

        @JavascriptInterface
        public void openExactAlarmSettings() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                }
            }
        }
    }

    private void setExactAlarm(AlarmManager am, long triggerAt, int requestCode,
                               String type, String prayerKey, String prayerName) {
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("type", type);
        intent.putExtra("prayerKey", prayerKey);
        intent.putExtra("prayerName", prayerName);

        PendingIntent pi = PendingIntent.getBroadcast(
                this, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }

    private void cancelAllAlarms() {
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int i = 0; i < 10; i++) {
            Intent intent = new Intent(this, AlarmReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(
                    this, 1000 + i, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
            pi = PendingIntent.getBroadcast(
                    this, 2000 + i, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
