package com.abosila.islamichub;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.Build;

import org.json.JSONObject;

import java.util.Calendar;

/**
 * After device reboot, re-schedule the last known prayer times.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
                && !"android.intent.action.QUICKBOOT_POWERON".equals(intent.getAction())) {
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences("prayer_times", Context.MODE_PRIVATE);
        String timesJson = prefs.getString("last_times", null);
        if (timesJson == null) return;

        try {
            JSONObject times = new JSONObject(timesJson);
            String[] keys = {"fajr", "dhuhr", "asr", "maghrib", "isha"};
            String[] names = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};

            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            Calendar now = Calendar.getInstance();

            for (int i = 0; i < keys.length; i++) {
                String t = times.optString(keys[i], null);
                if (t == null || t.equals("—") || !t.contains(":")) continue;

                String[] parts = t.split(":");
                int hour = Integer.parseInt(parts[0].trim());
                int minute = Integer.parseInt(parts[1].trim());

                Calendar adhanCal = Calendar.getInstance();
                adhanCal.set(Calendar.HOUR_OF_DAY, hour);
                adhanCal.set(Calendar.MINUTE, minute);
                adhanCal.set(Calendar.SECOND, 0);
                adhanCal.set(Calendar.MILLISECOND, 0);

                if (adhanCal.before(now)) {
                    adhanCal.add(Calendar.DAY_OF_YEAR, 1);
                }

                Calendar preCal = (Calendar) adhanCal.clone();
                preCal.add(Calendar.MINUTE, -5);

                if (preCal.after(now)) {
                    setAlarm(context, am, preCal.getTimeInMillis(), 1000 + i, "pre", keys[i], names[i]);
                }
                setAlarm(context, am, adhanCal.getTimeInMillis(), 2000 + i, "adhan", keys[i], names[i]);
            }
        } catch (Exception ignored) {}
    }

    private void setAlarm(Context ctx, AlarmManager am, long triggerAt, int reqCode,
                          String type, String key, String name) {
        Intent i = new Intent(ctx, AlarmReceiver.class);
        i.putExtra("type", type);
        i.putExtra("prayerKey", key);
        i.putExtra("prayerName", name);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, reqCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }
}
